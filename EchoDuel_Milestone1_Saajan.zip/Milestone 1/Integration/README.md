# Milestone 1 board top (Saajan + Kavin)

A key press plays a tone and lights that key on the VGA display.

```
PS/2 keyboard -> PS2_Controller -> note_decoder -> tone_gen -> Audio_Controller -> speaker
                                       |
                                       +-> kavin_milestone1 -> VGA monitor
```

## Controls

| Input | Action |
| --- | --- |
| KEY[0] | Reset |
| A S D F | Player 1 notes C, D, E, F |
| H J K L | Player 2, same four notes |

LEDs: LEDR[3:0] = note being held, LEDR[9] = player (on = Player 2).

## Before compiling in Quartus

1. Course PS/2 and Audio_Controller files are in `course_ps2/` and `course_audio/`.
2. **Still missing: `avconf.v` + `I2C_Controller.v`** (audio-chip setup). Put them in
   `course_audio/` and add them with **Project > Add/Remove Files**.
3. All pins match `C:\ece241\DE1_SoC.qsf` (checked).
4. Compile, program, plug the keyboard into the PS/2 port and speakers into line-out.

## Simulation (ModelSim, from `ModelSim/`)

- `do ps2_path.do`: fake keyboard wires -> **real** course PS2_Controller -> note_decoder -> tone_gen.
- `do echo_duel_m1.do`: whole board with simple stand-ins for the course PS/2 + audio
  (`tests/sim/course_stubs.v`, simulation only, never add to Quartus).
  Checks: holding D lights LEDR[2], plays sound and turns key 2 green; releasing turns it all off;
  K (Player 2) lights key 2 in the Player 2 group.
