create_clock -name CLOCK_50 -period 20.000 [get_ports {CLOCK_50}]
derive_pll_clocks
derive_clock_uncertainty
# Board I/O delays and CDC exceptions still require timing review on ECF.
